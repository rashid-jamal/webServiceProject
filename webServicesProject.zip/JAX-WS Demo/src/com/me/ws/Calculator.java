package com.me.ws;

import javax.jws.WebService;

@WebService(endpointInterface = "com.me.ws.CalculatorService")
public class Calculator{

	public int addition(int num1, int num2) {
		return num1+num2;
	}

	public int subtract(int num1, int num2) {
		return num1-num2;
	}

	public int multiply(int num1, int num2) {
		return num1*num2;
	}

	public int divide(int num1, int num2) {
		return num1/num2;
	}
}