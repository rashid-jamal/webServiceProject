package com.me.ws;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class CalculatorClient {

	public static void main(String[] args) throws Exception{
		URL url = new URL("http://127.0.0.1:6800/myself?wsdl");
		
		QName qname = new QName("http://ws.me.com/","CalculatorService");
		
		Service service = Service.create(url, qname);
		
		CalculatorService endPoint = service.getPort(CalculatorService.class);
		
		Scanner scInput = new Scanner(System.in);
		
		int num1 = 0 ;
		int num2 = 0 ;
		
		int answer = 0 ;
		
		System.out.print("Enter first number: ");
		num1 = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter second number: ");
		num2 = Integer.parseInt(scInput.nextLine());
		
		answer = endPoint.addition(num1, num2);
		System.out.println("Addition: " + answer);
		
		answer = endPoint.subtract(num1, num2);
		System.out.println("Subtraction: " + answer);
		
		answer = endPoint.multiply(num1, num2);
		System.out.println("Multiplication: " + answer);
		
		answer = endPoint.divide(num1, num2);
		System.out.println("Division: " + answer);
		
		scInput.close();
	}
}