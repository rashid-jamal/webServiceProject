package com.me.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style = Style.RPC)
public interface CalculatorService {

	@WebMethod
	int addition(int num1, int num2);
	
	@WebMethod
	int subtract(int num1, int num2);
	
	@WebMethod
	int multiply(int num1, int num2);
	
	@WebMethod
	int divide(int num1, int num2);
}